package org.atri.student.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.atri.student.entity.Score;

import java.util.List;

public interface ScoreMapper extends BaseMapper<Score> {

}
